# OpenWeatherMap API Key
weather_api_key = "a162be5bd9b675c040f478e1d2cceacc"

# Geoapify API Key
geoapify_key = "3f740ffc367e454a83dcd394d8bb3211"
